<?php
$style = 'class="form-control" id="submenu_id"';

echo form_dropdown("submenu_id", $submenu, '', $style);
?>
