<?php
$style = 'class="form-control" id="map_id"';
echo form_dropdown("map_id",$map,'',$style);
?>
