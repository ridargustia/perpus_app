<?php
$style = 'class="form-control" id="arsip_id"';
echo form_dropdown("arsip_id",$arsip,'',$style);
?>
